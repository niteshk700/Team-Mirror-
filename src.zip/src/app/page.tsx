import HeaderSection from "@/layout/header";
import Dashboard from "@/screens/page";
export default function Home() {
  return (
    <div>
      <HeaderSection />
      <Dashboard/>
    </div>
  );
}
