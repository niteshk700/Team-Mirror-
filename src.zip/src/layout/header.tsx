import Menu from "@/screens/common/menu";
import React from "react";
import { Toggle } from "@/components/ui/toggle";
import ProfileSection from "@/screens/common/profile";

function HeaderSection() {
  return (
    <div className="flex items-center justify-between px-4 py-4 gap-4">
      {/* Logo Section */}
      <div className="flex-1 text-left">
        <Toggle>TeamMirror</Toggle>
      </div>

      {/* Menu Section */}
      <div className="flex-1 text-center">
        <Menu />
      </div>

      {/* Profile Section */}
      <div className="flex-1 text-right">
        <ProfileSection />
      </div>
    </div>
  );
}

export default HeaderSection;
