import React from 'react'

function BodySection() {
  return (
    <div>
      
    </div>
  )
}

export default BodySection
