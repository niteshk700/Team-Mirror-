"use client";
import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Menu as MenuIcon, X } from "lucide-react";

export default function Menu() {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  return (
    <>
      {/* Desktop Navigation */}
      <div className="hidden md:block">
        <NavigationMenu>
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuTrigger>Employee</NavigationMenuTrigger>
              <NavigationMenuContent>
                <ul className="grid gap-3 p-4 md:w-[400px] lg:w-[500px] lg:grid-cols-[.75fr_1fr]">
                  <li className="row-span-3">
                    <NavigationMenuLink asChild>
                      <a
                        href="/employee"
                        className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-blue-100 to-blue-200 p-6 no-underline outline-none focus:shadow-md hover:shadow-lg transition-shadow"
                      >
                        <div className="text-2xl font-bold text-blue-900 mb-3">
                          Employee Portal
                        </div>
                        <p className="text-sm leading-tight text-blue-800">
                          Empower your team — find all employee resources
                          categorized for Senior Staff, Peers, and HR. Navigate
                          with ease!
                        </p>
                      </a>
                    </NavigationMenuLink>
                  </li>

                  <ListItem href="/employee/senior" title="Senior">
                    Access management tools and leadership insights.
                  </ListItem>
                  <ListItem href="/employee/peer" title="Peer">
                    Collaborate with your teammates and peers.
                  </ListItem>
                  <ListItem href="/employee/hr" title="HR">
                    Review policies, benefits, and employee support.
                  </ListItem>
                </ul>
              </NavigationMenuContent>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <Link href="/organisation" legacyBehavior passHref>
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Organisation
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <Link href="/faq" legacyBehavior passHref>
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  FAQ
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <Link href="/about" legacyBehavior passHref>
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  About
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <Link href="/contact" legacyBehavior passHref>
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Contact
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
      </div>

      {/* Mobile Hamburger Toggle */}
      <div className="md:hidden">
        <button
          className="text-gray-800"
          onClick={() => setMobileOpen((prev) => !prev)}
        >
          {mobileOpen ? <X size={24} /> : <MenuIcon size={24} />}
        </button>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileOpen && (
        <div className="absolute top-16 left-0 w-full bg-white shadow-md z-50 px-4 py-6 md:hidden">
          <ul className="space-y-4 text-gray-800">
            {/* Employee Dropdown */}
            <MobileDropdown title="Employee">
              <li>
                <Link
                  href="/employee/senior"
                  className="block w-full px-3 py-2 text-sm hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
                >
                  Senior
                </Link>
              </li>
              <li>
                <Link
                  href="/employee/peer"
                  className="block w-full px-3 py-2 text-sm hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
                >
                  Peer
                </Link>
              </li>
              <li>
                <Link
                  href="/employee/hr"
                  className="block w-full px-3 py-2 text-sm hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
                >
                  HR
                </Link>
              </li>
            </MobileDropdown>

            {/* Other Pages */}
            <li>
              <Link
                href="/organisation"
                className="block w-full py-2 text-base font-medium hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
              >
                Organisation
              </Link>
            </li>
            <li>
              <Link
                href="/faq"
                className="block w-full py-2 text-base font-medium hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
              >
                FAQ
              </Link>
            </li>
            <li>
              <Link
                href="/about"
                className="block w-full py-2 text-base font-medium hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
              >
                About
              </Link>
            </li>
            <li>
              <Link
                href="/contact"
                className="block w-full py-2 text-base font-medium hover:text-blue-600 hover:bg-blue-50 rounded-md text-left"
              >
                Contact
              </Link>
            </li>
          </ul>
        </div>
      )}
    </>
  );
}

const MobileDropdown = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => {
  const [open, setOpen] = React.useState(false);

  return (
    <li>
      <button
        onClick={() => setOpen((prev) => !prev)}
        className="w-full flex justify-between items-center text-base font-medium focus:outline-none"
      >
        <span>{title}</span>
        <span
          className={`transition-transform transform ${
            open ? "rotate-180" : ""
          }`}
        >
          ▼
        </span>
      </button>
      {open && <ul className="mt-2 pl-2 space-y-1">{children}</ul>}
    </li>
  );
};

const ListItem = React.forwardRef<
  React.ElementRef<"a">,
  React.ComponentPropsWithoutRef<"a">
>(({ className, title, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <a
          ref={ref}
          className={cn(
            "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
            className
          )}
          {...props}
        >
          <div className="text-sm font-medium leading-none">{title}</div>
          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
            {children}
          </p>
        </a>
      </NavigationMenuLink>
    </li>
  );
});
ListItem.displayName = "ListItem";
