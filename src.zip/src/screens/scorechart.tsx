"use client";

import { TrendingUp } from "lucide-react";
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

// Dummy data for performance metrics
const scoreChartData = [
  {
    metric: "Team Leadership",
    score: 80,
    change: "+3%",
    description: "Exemplary leadership qualities",
  },
  {
    metric: "Technical Capability",
    score: 90,
    change: "+5%",
    description: "Strong technical proficiency",
  },
  {
    metric: "Approachability",
    score: 85,
    change: "-2%",
    description: "High availability with a minor drop",
  },
  {
    metric: "Decision Making",
    score: 75,
    change: "-1%",
    description: "Opportunities to refine decision process",
  },
  {
    metric: "Problem Solving",
    score: 88,
    change: "+4%",
    description: "Effective in addressing challenges",
  },
  {
    metric: "Team Collaboration",
    score: 82,
    change: "+0%",
    description: "Consistent collaboration performance",
  },
];

// Chart configuration for a single "score" data series
const scoreChartConfig = {
  score: {
    label: "Score",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

function ScoreChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Score Trend</CardTitle>
        <CardDescription>
          Your performance score trend across key metrics
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={scoreChartConfig}>
          <AreaChart
            data={scoreChartData}
            margin={{
              left: 12,
              right: 12,
            }}
          >
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="metric"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" />}
            />
            <Area
              dataKey="score"
              type="monotone"
              fill="var(--chart-1)"
              fillOpacity={0.4}
              stroke="var(--chart-1)"
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
      <CardFooter>
        <div className="flex w-full items-start gap-2 text-sm">
          <div className="grid gap-2">
            <div className="flex items-center gap-2 font-medium leading-none">
              Trending up by 5.2% this period <TrendingUp className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-2 leading-none text-muted-foreground">
              Dummy data for demo purposes
            </div>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}

export default ScoreChart;
