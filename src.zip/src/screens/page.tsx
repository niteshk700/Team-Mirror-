"use client";
import React, { useState } from "react";
import ScoreCard from "./scorechart";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar } from "@/components/ui/calendar";
import { IndividualScoreTracker } from "./scorecards";

function Dashboard() {
  const [date, setDate] = useState<any>(new Date());

  return (
    <div className="flex flex-col md:flex-row gap-6 w-full px-4 md:px-0">
      {/* Left Column – 50% */}
      <div className="w-full md:w-1/2">
        <ScoreCard />
      </div>

      {/* Middle Column – 25% */}
      <div className="w-full md:w-1/4">
        <ScrollArea className="h-[34.2rem] w-full rounded-md border p-4">
          <IndividualScoreTracker/>
        </ScrollArea>
      </div>

      {/* Right Column – 25% */}
      <div className="w-full md:w-1/4">
        <Calendar
          mode="single"
          selected={date}
          onSelect={setDate}
          className="w-full rounded-md border"
        />
      </div>
    </div>
  );
}

export default Dashboard;
